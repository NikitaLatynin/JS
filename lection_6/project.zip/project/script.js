//TODOS
//1.Добавление задачи
//2.Удаление задачи
//3.Редактирование задачи


//Одна задача - это объект из следующих задач
//id - произвольная уникальная строка
//title - загаловок задачи
//text - текст задачи

let storage = {
    current_todos: [],
    deleted_todos: []
};

/**
 * generate_id - создает произвольную строку 
 * @returns {string} - новый id
 */
const generate_id = () => {
    const chars = '123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCCVBNM';
    let id = '';
    for(let i = 0; i <= 10; i++) id += chars[Math.floor(Math.random() * chars.length)];
    return id;
}

//Добавление задач
/**
 * add_new_todos -  функция для добавления новых задач
 * @param {String} title - заголовок задачи 
 * @param {String} text - описание задачи
 * @returns {void} 
 */
const add_new_todo = (title, text) => {
    if (!title) return 'Введите заголовок задачи';
    if (!text) return 'Введите текст задачи';

    const new_todo = {title, text, id: generate_id() };

    storage.current_todos.push(new_todo);

    return storage.current_todos.slice();
}

/**
 * delete_todo_item - удаление задачи по  id
 * @param {string} id 
 */
const delete_todo_item = id => {
    if (!id) return console.log('Передайте id удаляемой задачи.');

    storage.current_todos = storage.current_todos.filter(todo => {
        return todo.id !== id;
    });
    return storage.current_todos;
} 

/**
 * edit_todo_item - редактирование задачи по  id
 * @param {String} id 
 * @param {String} title - новый заголовок задачи 
 * @param {String} text - (необязательно) новый текст задачи
 */
const edit_todo_item = (id, title, text) => {
    if (!id) return console.log('Передайте id редактируемой задачи.');
    if (!title) return 'Введите новый заголовок задачи';
    storage.current_todos.forEach((item, index, arr) => {
        if (item.id == id) {
            item.title = title;
            if (text) item.text = text;
        } else console.log('Неверный id.');
    });
    return storage.current_todos;
}



















